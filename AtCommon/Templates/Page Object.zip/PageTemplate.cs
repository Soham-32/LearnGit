﻿using AgilityHealth_Automation.Base;
using OpenQA.Selenium;

namespace $rootnamespace$
{
    internal class $safeitemname$ : BasePage
    {
        public $safeitemname$(IWebDriver driver) : base(driver)
        {
        }

        // Locators


        // Methods




    }
}
