﻿using System.Net;
using System.Threading.Tasks;
using ApiTests.v1.Endpoints;
using AtCommon.Api;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    [TestClass]
    [TestCategory("")]
    public class $safeitemname$ : BaseV1Test
    {
        // 200-201
        [TestMethod]
        [TestCategory("")]
        public async Task Category_Subcategory_Method_Query_Scenario_StatusCode()
        {
            // given
            var client = await GetAuthenticatedClient();

            // when
            var response = await client.GetAsync<Dto>(RequestUris.Endpoint());

            // then
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode, "Status code doesn't match.");
        }

        // 400
        [TestMethod]
        [TestCategory("")]
        public async Task Category_Subcategory_Method_Query_Scenario_StatusCode()
        {
            // given
            var client = await GetAuthenticatedClient();

            // when
            var response = await client.GetAsync<Dto>(RequestUris.Endpoint());

            // then
            Assert.AreEqual(HttpStatusCode.BadRequest, response.StatusCode, "Status code doesn't match.");
        }

        // 401
        [TestMethod]
        [TestCategory("")]
        public async Task Category_Subcategory_Method_Query_Scenario_StatusCode()
        {
            // given
            var client = GetUnauthenticatedClient();

            // when
            var response = await client.GetAsync<Dto>(RequestUris.Endpoint());

            // then
            Assert.AreEqual(HttpStatusCode.Unauthorized, response.StatusCode, "Status code doesn't match.");
        }

        // 403
        [TestMethod]
        [TestCategory("")]
        public async Task Category_Subcategory_Method_Query_Scenario_StatusCode()
        {
            // given
            var client = await GetAuthenticatedClient();

            // when
            var response = await client.GetAsync<Dto>(RequestUris.Endpoint());

            // then
            Assert.AreEqual(HttpStatusCode.Forbidden, response.StatusCode, "Status code doesn't match.");
        }

        // 404
        [TestMethod]
        [TestCategory("")]
        public async Task Category_Subcategory_Method_Query_Scenario_StatusCode()
        {
            // given
            var client = await GetAuthenticatedClient();

            // when
            var response = await client.GetAsync<Dto>(RequestUris.Endpoint());

            // then
            Assert.AreEqual(HttpStatusCode.NotFound, response.StatusCode, "Status code doesn't match.");
        }
    }
}
