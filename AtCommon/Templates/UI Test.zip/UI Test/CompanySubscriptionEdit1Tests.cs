﻿using System;
using System.Threading.Tasks;
using AgilityHealth_Automation.Base;
using AgilityHealth_Automation.PageObjects.AgilityHealth.Account;
using AgilityHealth_Automation.Utilities;
using AtCommon.Api;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$
{
    [TestClass]
    [TestCategory("")]
    public class $safeitemname$ : BaseTest
    {

        [ClassInitialize]
        public static async Task ClassSetUp(TestContext testContext)
        {
            var setUp = new SetupTeardownApi(TestEnvironment);

        }


        [TestMethod]
        [TestCategory("")]
        public void TestMethod1()
        {
            var login = new LoginPage(Driver);

            Log.Info("Step 1 : Navigate to login page");
            Driver.NavigateToPage(ApplicationUrl);

            Log.Info("Step 2 : Login to application with valid credentials");
            login.LoginToApplication(User.Username, User.Password);


        }
    }
}
